<?php

namespace App\Admin\Controllers;

use App\Movie;

use Encore\Admin\Form;
use Encore\Admin\Grid;
use Encore\Admin\Facades\Admin;
use Encore\Admin\Layout\Content;
use App\Http\Controllers\Controller;
use Encore\Admin\Controllers\ModelForm;
use App\Admin\Extensions\ExcelExpoter;

class MovieController extends Controller
{
    use ModelForm;

    /**
     * Index interface.
     *
     * @return Content
     */
    public function index()
    {
        return Admin::content(function (Content $content) {


            $content->header('用户信息');
            $content->description('');

            $content->body($this->grid());
        });
    }

    /**
     * Edit interface.
     *
     * @param $id
     * @return Content
     */
    public function edit($id)
    {
        return Admin::content(function (Content $content) use ($id) {

            $content->header('用户信息');
            $content->description('编辑信息');

            $content->body($this->form()->edit($id));
        });
    }

    /**
     * Create interface.
     *
     * @return Content
     */
    public function create()
    {
        return Admin::content(function (Content $content) {

            $content->header('用户信息');
            $content->description('新增');

            $content->body($this->form());
        });
    }

    /**
     * Make a grid builder.
     *
     * @return Grid
     */
    protected function grid()
    {
        return Admin::grid(Movie::class, function (Grid $grid) {

            $grid->id('ID')->sortable();
            $grid->name('姓名');
            $grid->gender('性别');
            $grid->phone('电话');
            $grid->weixin_name('微信名称');
            $grid->weixin_num('微信号');
            $grid->source('来源渠道');
            $grid->city('所在地区');
            $grid->purpose('学习目的');
            $grid->course('意向课程');
            $grid->professional('职业');
            $grid->care('在意问题点');
            $grid->visitors('是否到访');
            $grid->text('详细信息');
            $grid->one_data('初次沟通');
            $grid->tow_data('二次沟通');
            $grid->three_data('三次沟通');
            $grid->created_at('创建时间');
            $grid->filter(function ($filter) {
                $filter->like('name','姓名');
                $filter->like('phone','电话');
                $filter->like('weixin_name','微信名称');
                $filter->like('weixin_num','微信号');
                $filter->like('source','来源渠道');
                $filter->like('visitors','是否到访');
                $filter->between('one_data','初次沟通时间')->datetime();

            });
            $grid->paginate(15);

            $excel = new ExcelExpoter();
            $excel->setAttr(['姓名','性别','电话','微信名称','微信号','来源渠道','所在地区','学习目的','意向课程','职业','在意问题点','是否到访','详细信息','初次沟通时间','二次沟通时间','三次沟通时间','创建时间'], ['name', 'gender', 'phone', 'weixin_name','weixin_num','source','city','purpose','course','professional','care','visitors','text','one_data','tow_data','three_data','created_at']);
            $grid->exporter($excel);
//            $grid->exporter(new ExcelExpoter());
//            $grid->model()->where('id', '<', 100);
        });
    }

    /**
     * Make a form builder.
     *
     * @return Form
     */
    protected function form()
    {

        return Admin::form(Movie::class, function (Form $form) {

            $form->display('id', 'ID');
            $form->text('name','姓名');
            $form->text('gender','性别');
            $form->mobile('phone','电话');
            $form->text('weixin_name','微信名称');
            $form->text('weixin_num','微信号');
            $form->text('source','来源渠道');
            $form->text('city','所在地区');
            $form->text('purpose','学习目的');
            $form->text('course','意向课程');
            $form->text('professional','职业');
            $form->text('care','在意问题点');
            $form->text('text','具体详细信息');
            $form->text('visitors','是否到访');
            $form->datetime('one_data','初次沟通');
            $form->datetime('tow_data','二次沟通');
            $form->datetime('three_data','三次沟通');
            $form->display('created_at', '创建时间');
            $form->display('updated_at', '更新时间');
        });
    }
}
